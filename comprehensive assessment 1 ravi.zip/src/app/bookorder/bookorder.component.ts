import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookorder',
  templateUrl: './bookorder.component.html',
  styleUrls: ['./bookorder.component.css']
})
export class BookorderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
