import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerComponent } from './customer/customer.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RecomendedComponent } from './recomended/recomended.component';
import { AdminComponent } from './admin/admin.component';
import { SearchComponent } from './search/search.component';
import { CartPageComponent } from './cart-page/cart-page.component';
import { FoodPageComponent } from './food-page/food-page.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { MyorderComponent } from './myorder/myorder.component';
import { BookorderComponent } from './bookorder/bookorder.component';
import { ListorderComponent } from './listorder/listorder.component';
import { AdminrouteComponent } from './adminroute/adminroute.component';
import { AddedtocartComponent } from './addedtocart/addedtocart.component';
import { OrderplacedComponent } from './orderplaced/orderplaced.component';
import { ListitemComponent } from './listitem/listitem.component';
@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    AboutComponent,
    LoginComponent,
    SignupComponent,
    RecomendedComponent,
    AdminComponent,
    SearchComponent,
    CartPageComponent,
    FoodPageComponent,
    MyorderComponent,
    BookorderComponent,
    ListorderComponent,
    AdminrouteComponent,
    AddedtocartComponent,
    OrderplacedComponent,
    ListitemComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    NgxPaginationModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
