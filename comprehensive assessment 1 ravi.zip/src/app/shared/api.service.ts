import { Injectable } from '@angular/core';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import {map} from 'rxjs/operators'
import { ListitemModel } from '../listitem/listitem.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  
  constructor( private http :HttpClient) { }
  postListitem(data : any)
  {
    return this.http.post<any>("http://localhost:3000/posts",data)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  getListitem()
  {
    return this.http.get<any>("http://localhost:3000/posts")
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  updateListitem(data:any, Customerid:number)
  {
    return this.http.put<any>("http://localhost:3000/posts" + Customerid,data)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  deleteListitem()
  {
    return this.http.delete<any>("http://localhost:3000/posts")
    .pipe(map((res:any)=>{
      return res;
    }))
  }
}
