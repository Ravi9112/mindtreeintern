import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CustomerComponent } from './customer/customer.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { RecomendedComponent } from './recomended/recomended.component';
import { AdminComponent } from './admin/admin.component';
import { SearchComponent } from './search/search.component';
import { FoodPageComponent } from './food-page/food-page.component';
import { CartPageComponent } from './cart-page/cart-page.component';
import { MyorderComponent } from './myorder/myorder.component';
import { BookorderComponent } from './bookorder/bookorder.component';
import { AdminrouteComponent } from './adminroute/adminroute.component';
import { ListitemComponent } from './listitem/listitem.component';

const routes: Routes = [
  {path:'customer',component:CustomerComponent},
  {path:'about',component:AboutComponent},
  {path:'login',component:LoginComponent},
  {path:'signup',component:SignupComponent},
  {path:'recomended',component:RecomendedComponent},
  {path:'admin',component:AdminComponent},
  {path:'search/:searchItem',component:RecomendedComponent},
  {path:'food/:id', component:FoodPageComponent},
  {path:'cart-page',component:CartPageComponent},
  {path:'myorder',component:MyorderComponent},
  {path:'bookorder',component:BookorderComponent},
  {path:'adminroute',component:AdminrouteComponent},
  {path:'listitem',component:ListitemComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
