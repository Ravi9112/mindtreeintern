import { Injectable } from '@angular/core';
import { Foods } from 'src/app/shared/models/food';

@Injectable({
  providedIn: 'root'
})
export class FoodService {

  constructor() { }

   getFoodById(id:number):Foods{
     return this.getAll().find(food => food.id == id)!;
   }
  getAll():Foods[]{
  return[
    {
      id:  1,
      name:'Biryani',
      price:150,
      imageUrl:'/assets/biryani.jpg'

    },
    {
      id:  2,
      name:'Dosa',
      price:90,
      imageUrl:'/assets/dosa.jpg'

    },
    {
      id:  3,
      name:'Chilli potato',
      price:80,
      imageUrl:'/assets/chilli.jpg'

    },
    {
      id:  4,
      name:'pizza',
      price:250,
      imageUrl:'/assets/pizza.jpg'

    },
    {
      id:  5,
      name:'Mutton',
      price:300,
      imageUrl:'/assets/mutton.jpg'

    },
    {
      id:  6,
      name:'Rasgulla',
      price:50,
      imageUrl:'/assets/rasgulla.jpg'

    },
    {
      id:  7,
      name:'Ice-Cream',
      price:90,
      imageUrl:'/assets/icecream.jpg'

    },
    {
      id:  8,
      name:'Pastry',
      price:100,
      imageUrl:'/assets/pastry.jpg'

    },
    {
      id:  9,
      name:'Burger',
      price:60,
      imageUrl:'/assets/burger.jpg'

    },
    {
      id:  10,
      name:'Special Thali',
      price:140,
      imageUrl:'/assets/thali.jpg'

    },
    {
      id:  11,
      name:'Special Thali',
      price:140,
      imageUrl:'/assets/thali.jpg'

    },
    {
      id:  12,
      name:'Special Thali',
      price:140,
      imageUrl:'/assets/thali.jpg'

    },
    {
      id:  13,
      name:'Special Thali',
      price:140,
      imageUrl:'/assets/thali.jpg'

    },
    {
      id:  14,
      name:'Special Thali',
      price:140,
      imageUrl:'/assets/thali.jpg'

    },
    {
      id:  15,
      name:'Special Thali',
      price:140,
      imageUrl:'/assets/thali.jpg'

    },
    {
      id:  16,
      name:'Mutton',
      price:140,
      imageUrl:'/assets/mutton.jpg'

    },
    {
      id:  17,
      name:'Mutton',
      price:140,
      imageUrl:'/assets/mutton.jpg'

    },
    {
      id:  18,
      name:'Special Thali',
      price:140,
      imageUrl:'/assets/thali.jpg'

    },
    {
      id:  19,
      name:'MUTTON',
      price:140,
      imageUrl:'/assets/mutton.jpg'

    },
    {
      id:  20,
      name:'ice cream',
      price:140,
      imageUrl:'/assets/icecream.jpg'

    }
 ];
  }
}

