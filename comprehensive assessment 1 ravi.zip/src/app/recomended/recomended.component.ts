import { Component, OnInit } from '@angular/core';
import { FoodService } from '../services/food/food.service';
import { Foods } from '../shared/models/food';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-recomended',
  templateUrl: './recomended.component.html',
  styleUrls: ['./recomended.component.css']
})
export class RecomendedComponent implements OnInit {
  foods:Foods[]=[];
  p: number = 1;
  list= [{"id":1, "name":"ravi" ,"city":"gkp"},
  {"id":2, "name":"ravi" ,"city":"gkp"},
  {"id":3, "name":"ravi" ,"city":"gkp"},
  {"id":4, "name":"ravi" ,"city":"gkp"},
  {"id":5, "name":"ravi" ,"city":"gkp"},
  {"id":6, "name":"ravi" ,"city":"gkp"},
  {"id":7, "name":"ravi" ,"city":"gkp"},
  {"id":8, "name":"ravi" ,"city":"gkp"},
]

  constructor(private fs:FoodService,private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(params =>{
      if(params['searchItem'])
      this.foods = this.fs.getAll().filter(food =>food.name.toLowerCase().includes(params['searchItem'].toLowerCase()))
      else
      this.foods = this.fs.getAll();
    })
   this.foods = this.fs.getAll();
  }

}
