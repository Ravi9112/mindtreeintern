import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ListitemModel } from './listitem.model';
import { ApiService } from '../shared/api.service';

@Component({
  selector: 'app-listitem',
  templateUrl: './listitem.component.html',
  styleUrls: ['./listitem.component.css']
})
export class ListitemComponent implements OnInit {
  formValue !:FormGroup;
  listitemModelObj :ListitemModel = new ListitemModel();
 
  constructor(private formbuilder:FormBuilder , private api :ApiService) { }


  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      name :[''],
      price :['']
    })
   
  }
  postListitemDetails(){
    this.listitemModelObj.Name = this.formValue.value.name;
    this.listitemModelObj.Price = this.formValue.value.price;

    this.api.postListitem(this.listitemModelObj)
    .subscribe((res: any) =>{
      console.log(res);
      alert("added successfully");
    },
    ()=>{
      alert("something went wrong");
    })
  }
}

