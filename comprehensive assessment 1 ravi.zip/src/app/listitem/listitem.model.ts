export class ListitemModel{
   id:number = 0;
    Name : string = '';
    Price : string ='';
}