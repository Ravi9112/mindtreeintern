import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminroute',
  templateUrl: './adminroute.component.html',
  styleUrls: ['./adminroute.component.css']
})
export class AdminrouteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
