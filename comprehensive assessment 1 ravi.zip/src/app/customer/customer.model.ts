export class CustomerModel{
    Customerid : number=0;
    Name : string = '';
    Mobile: string = '';
    Email : string = '';
    Gender : string = '';
    Place : string ='';
}