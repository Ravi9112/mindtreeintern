import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addedtocart',
  templateUrl: './addedtocart.component.html',
  styleUrls: ['./addedtocart.component.css']
})
export class AddedtocartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
