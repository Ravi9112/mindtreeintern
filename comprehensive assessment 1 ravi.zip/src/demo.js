/*const {MongoClient} = require('mongodb')
const url ='mongodb://localhost:27017';
const databaseName='meanstack'
const client= new MongoClient(url);

async function getData()
{
    let result=await client.connect();
    db= result.db(databaseName);
    collection = db.collection('userdata');
    let data = await collection.find({}).toArray();
    console.log(data)
}
getData();*/
var mongo = require('mongodb');
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/meanstack";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  console.log("Database created!");
  db.close();
});

